package com.example.menslides;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.xml.transform.Result;

public class loginpage extends AppCompatActivity {

    Button registertomainactivity;

    EditText password;
    CheckBox showpassword;

    String connectionString = "Server=10.15.51.21;Port=3306;User=root;Password=Admin123;Database=DataBased;";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loginpage);
        registertomainactivity = (Button) findViewById(R.id.registrieren);
        registertomainactivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMenupage();
            }
        });

        password = findViewById(R.id.password);
        showpassword = findViewById(R.id.showpassword);


        showpassword.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    password.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                } else {
                    password.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }
            }
        });

        String url = " jdbc:mysql://localhost:3306/databased?autoReconnect=true&useSSL=false";
        String user = "root";
        String password = "secret";


        try {
            Connection myConn = DriverManager.getConnection(url, user, password);
            Statement myStmt = myConn.createStatement();

            String sql = "select * from mydb.Contacts";
            ResultSet rs = myStmt.executeQuery(sql);

            while (rs.next())
                System.out.println(rs.getString("u_email"));
        } catch (SQLException e) {
            e.printStackTrace();
        }


    }

    public void openMenupage() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}

