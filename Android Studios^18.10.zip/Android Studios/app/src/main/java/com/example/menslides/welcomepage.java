package com.example.menslides;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class welcomepage extends AppCompatActivity {

    Button logintologinpage;

    Button logintonav2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcomepage);
        logintologinpage = (Button) findViewById(R.id.Signup);
        logintologinpage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               openLoginPage();
            }
        });
        logintonav2 = (Button) findViewById(R.id.login);
        logintonav2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { openNav2Menu();

            }
        });
    }
    public void openLoginPage() {
        Intent intent = new Intent(this, loginpage.class);
        startActivity(intent);
    }

    public void openNav2Menu(){
        Intent intent = new Intent(this, navibar2.class);
        startActivity(intent);
    }
}