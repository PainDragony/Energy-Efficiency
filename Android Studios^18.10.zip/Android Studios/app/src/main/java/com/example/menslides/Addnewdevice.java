package com.example.menslides;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Camera;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.AndroidException;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class Addnewdevice extends AppCompatActivity {

    Button opnencamera;
    ImageView showtakenpicture;
    TextView newDeviceMainActivity;
    private static final int MY_CAMERA_REQUEST_CODE = 100;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addnewdevice);

        opnencamera = findViewById(R.id.cameraopen);
        newDeviceMainActivity = findViewById(R.id.leavingadnewdevice);
        showtakenpicture = findViewById(R.id.showtakenpicture);

        if (ActivityCompat.checkSelfPermission(Addnewdevice.this, android.Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
            ActivityCompat.requestPermissions(Addnewdevice.this, new String[]{android.Manifest.permission.CAMERA}, 0);

        opnencamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    Intent intent = new Intent();
                    intent.setAction(MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivityForResult(intent,100);


            }
        });

        
        newDeviceMainActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openMenupage();
            }
        });
    }
    public void openMenupage() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 100)
        {
            Bitmap bitmap = (Bitmap) data.getExtras().get("data");
            showtakenpicture.setImageBitmap(bitmap);
        }
    }
}